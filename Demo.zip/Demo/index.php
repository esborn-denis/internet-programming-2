<?php
if(isset($_POST['submit'])){
    
    $balance = $_POST['balance'];
    
    echo "Your balance is: $balance" ;
         
    
            
            

}

?>



<a href=""></a>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<body>
  <form action="" method="post">
      <label for="balance">ENTER YOUR BALANCE</label>
      
      <input type="number" name="balance">
      <br>
      <br>
      <input type="submit" name="submit">
      <a href="withdrawal.php?balance=<?= $balance ?>">withdraw</a>
      <a href="deposit.php?balance= <?= $balance ?>">Deposit</a>
      
  </form>  
</body>
</html>