<?php
if(isset($_POST['submit'])){
    
    $amount = $_POST['amount'];
    
    $balance = $_GET['balance'];
    
    $balance  = $balance + $amount;
    
    echo "Your balance is: $balance" ;
    
    
            
            

}

?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<body>
   
    <form action="" method="post">
      <label for="balance">ENTER  AMOUT</label>
      
      <input type="number" name="amount">
      <br>
      <br>
      <input type="submit" name="submit">
      <a href="withdrawal.php?balance=<?= $balance ?>">withdraw</a>
      <a href="index.php".php?balance= <?= $balance ?>">Home</a>
      
      
  </form>
    
</body>
</html>